(() => {
	const path = require('path');
	const fs = require('fs').promises;

	async function save(filePath, content) {
		const directory = path.dirname(filePath);

		try {
			await fs.access(directory);
		}
		catch(error) {
			if (error.code == 'ENOENT') {
				try {
					await fs.mkdir(directory, {recursive: true});
					console.log('Directory created successfully:', directory);
				}
				catch(err) {
					console.error('Error creating directory');
					throw err;
				}
			}
			else {
				console.error('Error accessing directory:');
				throw err;
			}
		}

		try {
			await fs.writeFile(filePath, content);
			console.log('saved ' + filePath);
		}
		catch(err) {
			console.error('error while saving');
			throw err;
		}
	}

	function getStringsWithSimilarEndings(strs, options) {
		// getStringsWithSimilarEndings(['tX', '05b3925eyhwtX', 'a9680277yhwtX', '2af0e959yhwtX-legacy', 'f933f8dcyhwtX-legacy', 'sghdfnegehu']);
		// returns
		// {
			// sghdfnegehu: ["sghdfnegehu"]
			// tX: ["tX"]
			// yhwtX: ["05b3925eyhwtX", "a9680277yhwtX"]
			// "yhwtX-legacy": ["2af0e959yhwtX-legacy", "f933f8dcyhwtX-legacy"]
		// }
		// ChatGPT calculates the speed to be O(n^2)

		if (!Array.isArray(strs)) {
			throw new Error('strs in getStringsWithSimilarEndings must be an Array');
		}

		if (!options || typeof options != 'object') {
			options = {};
		}
		if (typeof options.minCommon != 'number' || !isFinite(options.minCommon)) {
			options.minCommon = 1;
		}

		let entries = {};
		let endings = {};

		for (let i = 0; i < strs.length; i++) {
			const str1 = strs[i];

			if (typeof str1 != 'string') {
				throw new Error(`strs[${i}] in getStringsWithSimilarEndings is not a string`);
			}

			// j = i + 1 covers all necessary comparisons
			for (let j = i + 1; j < strs.length; j++) {
				const str2 = strs[j];

				if (typeof str2 != 'string') {
					throw new Error(`strs[${j}] in getStringsWithSimilarEndings is not a string`);
				}

				let ending = '';
				let k = 1;

				while (str1[str1.length - k] == str2[str2.length - k]) {
					ending = str1[str1.length - k] + ending;
					k++;

					if (k > str1.length || k > str2.length) {
						break;
					}
				}

				if ((ending.length > (entries[str1] ? entries[str1] : '').length) && (ending.length > (entries[str2] ? entries[str2] : '').length)) {
					entries[str1] = ending;
					entries[str2] = ending;
				}
			}
		}

		for (let str of strs) {
			if (!entries[str]) {
				entries[str] = str;
			}

			if (!endings[entries[str]]) {
				endings[entries[str]] = [];
			}

			endings[entries[str]].push(str);
		}

		// this loop might not be needed based on inputs
		const endingNames = Object.getOwnPropertyNames(endings);

		for (let ending of endingNames) {
			if (endings[ending].length < 2 && endings[ending][0].length < ending.length) {
				const str = endings[ending].pop();
				delete endings[ending];
				endings[str] = [str];
			}
		}

		return endings;
	}

	function formatFileSize(bytes) {
		// based on ChatGPT

		if (typeof bytes != 'number') {
			throw new Error('bytes in formatFileSize is not a number, received a ' + typeof(bytes));
		}

		if (bytes == 0) {
			return '0 B';
		}

		const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
		const digitGroups = Math.floor(Math.log(bytes) / Math.log(1024));

		return parseFloat((bytes / Math.pow(1024, digitGroups)).toFixed(2)) + ' ' + units[digitGroups];
	}

	module.exports = {save, getStringsWithSimilarEndings, formatFileSize};
})();