These are reconstructions of a phishing sites (https://everi.tairongss.com/uk/ and https://evriil.com/i/, which I believe to be linked to same owners), client-side only. If you want to experiment with the sites, disconnect from the internet to prevent details you enter from being submitted successfully. Pressing the Continue button doesn't work, likely because this isn't website but a local page.

All files other than save.js, scraper.js, View page source.txt, external_urls.txt, internal_urls.txt and this README.txt file are the client-side parts of the site.

utils.js is used by scraper.js.

scraper.js is for finding urls from the site (such as scripts and stylesheets). Files which don't exist on your file system will be created, with 0 bytes content. Go to the related page on the actual phishing website and copy the source code from there. To use, NodeJS must be installed then use Command Prompt etc. to run the command "node scraper.js" from within this directory. All files that have been detected using scraper.js have been filled with the appropriate content. Any files with 0 bytes content were unable to be obtained (site was taken down).

View page source.txt is for a bookmarklet for iPhone/iPad.
To make the bookmarklet:
1) Add website as Favorite
2) Edit name to View page source
3) Change url to what's in the file

To use:
1) Go to a website
2) Click the book icon
3) Go to Favorites
4) Click View page source
A new window displaying the page's source code will open. The source code will automatically be selected.

external_urls.txt lists all the external websites the sites reference. Which external website and which file references it as well as number of times is included.
internal_urls.txt is like external_urls.txt but for internal urls.