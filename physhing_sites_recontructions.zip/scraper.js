(async () => {
	const path = require('path');
	const fs = require('fs').promises;
	const utils = require('./utils.js');

	let scraped = {};
	let internalUrls = {};
	let externalUrls = {};

	function getRelativePath(site, path) {
		return path.replace(new RegExp(/.+/.source + site), '');
	}

	function urlReferencesToHumanReadadble(urlRefList) {
		let str = '';

		for (let site in urlRefList) {
			str += '\n\n' + site;

			for (let url in urlRefList[site]) {
				str += '\n> ' + url;

				for (let fromFile in urlRefList[site][url]) {
					const numTimes = urlRefList[site][url][fromFile];

					str += '\n>> ' + fromFile + ' ' + numTimes;
				}
			}
		}

		return str.trim();
	}

	async function scrape(site, filePath) {
		filePath = path.resolve(filePath);
		process.chdir(path.dirname(filePath));

		if (scraped[site][filePath]) {
			return;
		}

		scraped[site][filePath] = true;

		const fileContent = await (async () => {
			try {
				return await fs.readFile(filePath, 'utf8');
			}
			catch(err) {
				// automatically create the file
				await utils.save(filePath, '');
				return '';
			}
		})();

		const fileType = path.extname(filePath).toLowerCase().replace(/^\./, '');

		if (!(['html', 'js', 'css'].includes(fileType))) {
			// console.log(filePath + ' is not a plain text file');
			return;
		}

		let urlRe = /(\.\.?\/[^.]+\.[A-Za-z0-9]+)/;
		let externalUrlRe;

		if (fileType == 'css') {
			urlRe = /(?:url\(['"]?)/.source + urlRe.source + /(?:\))/.source;
			externalUrlRe = /(?:url\(['"]?)/.source + /(https?:\/\/[^\)]+)/.source + /(?:['"]?\))/.source;
		}
		else {
			urlRe = /(?:['"])/.source + urlRe.source + /(?:['"])/.source;
			externalUrlRe = /(?:['"])/.source + /(https?:\/\/[^'"]+)/.source + /(?:['"])/.source;
		}

		urlRe = new RegExp(urlRe);
		externalUrlRe = new RegExp(externalUrlRe);

		const externalsUrlMatches = fileContent.match(new RegExp(externalUrlRe, 'g'));
		const actualFileName = getRelativePath(site, filePath);

		if (externalsUrlMatches) {
			for (let match of externalsUrlMatches) {
				const url = match.match(externalUrlRe)[1];

				if (!externalUrls[site][url]) {
					externalUrls[site][url] = {};
				}

				if (!externalUrls[site][url][actualFileName]) {
					externalUrls[site][url][actualFileName] = 0;
				}

				externalUrls[site][url][actualFileName]++;
			}
		}

		const urlMatches = fileContent.match(new RegExp(urlRe, 'g'));

		if (urlMatches) {
			if (!internalUrls[site][actualFileName]) {
				internalUrls[site][actualFileName] = {};
			}

			for (let match of urlMatches) {
				// console.log('in file ' + filePath);

				const url = path.resolve(match.match(urlRe)[1]);
				const actualFileName2 = getRelativePath(site, url);

				if (!internalUrls[site][actualFileName][actualFileName2]) {
					internalUrls[site][actualFileName][actualFileName2] = 0;
				}

				internalUrls[site][actualFileName][actualFileName2]++;

				await scrape(site, url);
				process.chdir(path.dirname(filePath));
			}
		}
	}

	const originalDirectory = path.resolve(process.cwd());
	const sites = ['evriil.com', 'evri.tairongss.com'];

	for (let site of sites) {
		scraped[site] = {};
		internalUrls[site] = {};
		externalUrls[site] = {};

		const subdirectory = await (async () => {
			return await fs.readdir(site)
				.then((files) => {
					return files[0];
				});
		})();

		await scrape(site, path.join(site, subdirectory, 'index.html'));
		process.chdir(originalDirectory);
	}

	let filesComparison = '';

	for (let site in scraped) {
		const strs = [];

		for (let filePath in scraped[site]) {
			strs.push(filePath);
		}

		const similarEndings = utils.getStringsWithSimilarEndings(strs);
		let filesComparer = {};

		for (let ending in similarEndings) {
			filesComparer[ending] = [];

			for (let filePath of similarEndings[ending]) {
				filesComparer[ending].push({path: filePath, size: (await fs.stat(filePath)).size});
			}

			filesComparer[ending] = filesComparer[ending].sort((a, b) => {
				return b.size - a.size;
			});
		}

		filesComparison += '\n\n' + site;

		for (let ending in filesComparer) {
			filesComparison += '\n> ' + getRelativePath(site, ending) + ' (' + filesComparer[ending].length + ')';

			for (let file of filesComparer[ending]) {
				filesComparison += '\n>> ' + getRelativePath(site, file.path) + ' ' + utils.formatFileSize(file.size);
			}
		}
	}

	await utils.save('external_urls.txt', urlReferencesToHumanReadadble(externalUrls));
	await utils.save('internal_urls.txt', urlReferencesToHumanReadadble(internalUrls));
	await utils.save('files_comparision.txt', filesComparison.trim());

	console.log('done');
})();